﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Author: Ariel Gordon
// Program: ​A simple GUI with the appropriate buttons and feedback needed to control the NEC Projector. 
// Date: 04/8/2019

namespace ProjectorController
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
