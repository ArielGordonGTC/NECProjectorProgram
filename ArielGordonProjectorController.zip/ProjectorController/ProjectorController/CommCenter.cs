﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Timers;
using System.Threading;
using System.Threading.Tasks;

namespace ProjectorController
{
    class CommCenter
    {
        string necMessage;
        public void CommSender(byte[] sendMessage)
        {
            try
            {
                // Establish the remote endpoint for the socket.  .  
                IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 7142);

                // Create a TCP/IP  socket.  
                Socket sender = new Socket(ipAddress.AddressFamily,SocketType.Stream, ProtocolType.Tcp);

                // Connect the socket to the remote endpoint. Catch any errors. 
                try
                {
                    // Establishes a connection to a remote host  
                    sender.Connect(remoteEP);

                    // Connection message to console
                    Console.WriteLine("Socket connected to {0}",
                    sender.RemoteEndPoint.ToString());

                    // Sends data to a connected Socket.  
                    sender.Send(sendMessage);

                    // Receiving byte array   
                    byte[] bytes = new byte[1024];

                    // Receives data from a bound Socket.  
                    int bytesRec = sender.Receive(bytes);

                    // Converts byte array to string  
                    String theMessageToReceive = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                    // Continues to read the data till data isn't available  
                    while (sender.Available > 0)
                    {
                        bytesRec = sender.Receive(bytes);
                        theMessageToReceive += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                    }

                    // Store message from projector
                    this.necMessage = theMessageToReceive;

                    // Release the socket.  
                    sender.Shutdown(SocketShutdown.Both);
                    sender.Close();
                }
                catch (SocketException se)
                {
                    Console.WriteLine("SocketException : {0}", se.ToString());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception : {0}", e.ToString());
            }

        }  
        
        // Method for other classes to get projector message/status
        public string getProjectorData()
        {
            return this.necMessage;
        }

    }
}
