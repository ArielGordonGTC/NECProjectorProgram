﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectorController
{
    public partial class InputButtons : UserControl
    {
        private byte[] vga1Input = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x01, };
        private byte[] vga2Input = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x02, };
        private byte[] videoInput = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x06, };
        private byte[] component1Input = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x10, };
        private byte[] hdmi1Input = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x1A, };
        private byte[] hdmi2Input = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x1B, };
        private byte[] lanInput = new byte[] { 0x02, 0x03, 0x00, 0x00, 0x02, 0x01, 0x20, };
        public InputButtons()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(vga1Input);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(vga2Input);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(videoInput);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(component1Input);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(hdmi1Input);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(hdmi2Input);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(lanInput);
        }

        private void InputButtons_Load(object sender, EventArgs e)
        {

        }
    }
}
