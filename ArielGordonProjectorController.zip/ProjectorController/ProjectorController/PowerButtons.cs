﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectorController
{
    public partial class PowerButtons : UserControl
    {

        private byte[] powerOnCmd = new byte[] { 0x02, 0x00, 0x00, 0x00, 0x00, 0x02, };
        private byte[] powerOffCmd = new byte[] { 0x02, 0x01, 0x00, 0x00, 0x00, 0x03, };


        public PowerButtons()
        {
            InitializeComponent();
        }

        private void PowerButtons_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(powerOffCmd);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(powerOnCmd);
        }
    }
}
