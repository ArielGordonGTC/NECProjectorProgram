﻿namespace ProjectorController
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.volumeButtons1 = new ProjectorController.VolumeButtons();
            this.powerButtons1 = new ProjectorController.PowerButtons();
            this.inputButtons1 = new ProjectorController.InputButtons();
            this.projectorStatus1 = new ProjectorController.ProjectorStatus();
            this.SuspendLayout();
            // 
            // volumeButtons1
            // 
            this.volumeButtons1.Location = new System.Drawing.Point(149, 11);
            this.volumeButtons1.Name = "volumeButtons1";
            this.volumeButtons1.Size = new System.Drawing.Size(150, 150);
            this.volumeButtons1.TabIndex = 4;
            // 
            // powerButtons1
            // 
            this.powerButtons1.Location = new System.Drawing.Point(12, 12);
            this.powerButtons1.Name = "powerButtons1";
            this.powerButtons1.Size = new System.Drawing.Size(150, 150);
            this.powerButtons1.TabIndex = 3;
            this.powerButtons1.Load += new System.EventHandler(this.powerButtons1_Load);
            // 
            // inputButtons1
            // 
            this.inputButtons1.Location = new System.Drawing.Point(305, 11);
            this.inputButtons1.Name = "inputButtons1";
            this.inputButtons1.Size = new System.Drawing.Size(295, 149);
            this.inputButtons1.TabIndex = 5;
            // 
            // projectorStatus1
            // 
            this.projectorStatus1.Location = new System.Drawing.Point(12, 184);
            this.projectorStatus1.Name = "projectorStatus1";
            this.projectorStatus1.Size = new System.Drawing.Size(434, 150);
            this.projectorStatus1.TabIndex = 6;
            this.projectorStatus1.Load += new System.EventHandler(this.projectorStatus1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 346);
            this.Controls.Add(this.projectorStatus1);
            this.Controls.Add(this.inputButtons1);
            this.Controls.Add(this.volumeButtons1);
            this.Controls.Add(this.powerButtons1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private PowerButtons powerButtons1;
        private VolumeButtons volumeButtons1;
        private InputButtons inputButtons1;
        private ProjectorStatus projectorStatus1;
    }
}