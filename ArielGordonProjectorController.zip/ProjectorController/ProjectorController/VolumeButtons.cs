﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectorController
{
    public partial class VolumeButtons : UserControl
    {
        private byte[] volumeUpCmd   = new byte[] { 0x03, 0x10, 0x00, 0x00, 0x05, 0x05, 0x00, 0x01, 0x14, 0x00, };
        private byte[] volumeDownCmd = new byte[] { 0x03, 0x10, 0x00, 0x00, 0x05, 0x05, 0x00, 0x01, 0x14, };
        private byte[] volumeMuteOnCmd = new byte[] { 0x02, 0x12, 0x00, 0x00, 0x00, 0x14, };
        private byte[] volumeMuteOffCmd = new byte[] { 0x02, 0x13, 0x00, 0x00, 0x00, 0x15, };

        public VolumeButtons()
        {
            InitializeComponent();
        }

        private void VolumeButtons_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(volumeMuteOnCmd);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(volumeDownCmd);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(volumeUpCmd);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CommCenter com = new CommCenter();
            com.CommSender(volumeMuteOffCmd);
        }
    }
}
