Author: Ariel Gordon
Program: ?A simple GUI with the appropriate buttons and feedback needed to control the NEC Projector. 
Date: 04/8/2019

Known issues: Able to send and recieve a few commands from NEC emulator but unable to resolve socket issue causing program lockup. Status polling incomplete due to time debugging socket issue.